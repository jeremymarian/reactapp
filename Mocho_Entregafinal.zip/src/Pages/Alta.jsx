import Altaprod from "../componentes/Altaprod"

const Alta = () => <Altaprod  />

export default  Alta