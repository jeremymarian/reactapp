import Logform from "../componentes/Logform";

const Login = () => {
    return <Logform />
     
}
    
    export default Login