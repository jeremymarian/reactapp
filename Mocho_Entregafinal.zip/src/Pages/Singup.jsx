import {Singform} from "../componentes/Singform"

function Singup () {
return <Singform />
}

export default Singup