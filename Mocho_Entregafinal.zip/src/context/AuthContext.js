import React, { useState } from "react"
import firebase from "../Services/firebase"

export const AuthContext = React.createContext()

const AuthProvider = ({children}) => {



    const [login, setLogin] = useState(localStorage.getItem("login")||false)
    const [userName, setUserName] = useState(localStorage.getItem("userName"))
  

    const handlerLogin =  async () => {
        setLogin(true)
        localStorage.setItem("login",true)
        const auth = firebase.auth().currentUser.uid
        const userResponse = await firebase.firestore().collection("usuarios")
             .where("userId","==",auth)
             .get()
        const user = userResponse.docs[0].data()
        setUserName(user?.name)
        localStorage.setItem("userName",user?.name) 
        
            
  
           
            
       


        }
        
       
  
              
         


    const handlerLogOut = () => {
        setLogin(localStorage.removeItem("login"))
        setUserName(localStorage.removeItem("userName"))
        }
     
         
  
        
      


       

return (
    <AuthContext.Provider
    value={{login ,handlerLogin, handlerLogOut,userName}}>

    {children}
    </AuthContext.Provider>
)

    }

    export default AuthProvider
