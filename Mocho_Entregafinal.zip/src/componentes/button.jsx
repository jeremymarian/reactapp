


function averSiFunc () {

const wega = document.getElementsByClassName("holav")
  
console.log(wega)
return( console.log(wega[0].innerHTML = "Gracias por su compra")  )


  }


function Buttonf ({pePe}) { 


return (
<div><button onClick={pePe}>COMPRAR</button>

</div>
)
}


export default Buttonf
export{averSiFunc}

