export const loginMessage={
    "auth/user-not-found":"Email no existe",
    "auth/wrong-password":"Contraseña incorrecta"
}
export const registroMessage={
    "auth/email-already-in-use":"Email en uso"
}